
import React, { useState, useEffect, useRef } from 'react';
import { Teacher, ScheduleEntry, Absence, SlotType, Role } from './types';
import { TIME_SLOTS, DAYS_OF_WEEK } from './constants';
import { 
  Users, 
  Calendar, 
  Clock, 
  ShieldAlert, 
  ClipboardCheck, 
  BarChart3, 
  UserPlus,
  BookOpen,
  CalendarRange,
  Sparkles,
  Zap,
  User as UserIcon,
  AlertCircle,
  ChevronLeft,
  ChevronRight,
  Trash2,
  CalendarCheck,
  CheckCircle2,
  Upload,
  Camera
} from 'lucide-react';

// --- Helpers de Persistencia ---
const loadData = <T,>(key: string, defaultValue: T): T => {
  try {
    const saved = localStorage.getItem(key);
    return saved ? JSON.parse(saved) : defaultValue;
  } catch (e) { return defaultValue; }
};

const saveData = (key: string, data: any) => localStorage.setItem(key, JSON.stringify(data));

const initialTeachers: Teacher[] = [
  { id: 'admin-001', name: 'Control de Guardias', role: 'admin' },
];

const App: React.FC = () => {
  const [teachers, setTeachers] = useState<Teacher[]>(() => loadData('teachers', initialTeachers));
  const [schedules, setSchedules] = useState<ScheduleEntry[]>(() => loadData('schedules', []));
  const [absences, setAbsences] = useState<Absence[]>(() => loadData('absences', []));
  const [view, setView] = useState<'dashboard' | 'absences' | 'stats' | 'teachers' | 'master-guards' | 'daily-tasks' | 'manage-schedules'>('dashboard');
  const [selectedTeacherForSchedule, setSelectedTeacherForSchedule] = useState<Teacher | null>(null);

  useEffect(() => { saveData('teachers', teachers); }, [teachers]);
  useEffect(() => { saveData('schedules', schedules); }, [schedules]);
  useEffect(() => { saveData('absences', absences); }, [absences]);

  const addTeacher = (name: string, avatarUrl?: string) => {
    const newTeacher: Teacher = { 
      id: Math.random().toString(36).substr(2, 9), 
      name, 
      role: 'teacher',
      avatarUrl
    };
    setTeachers(prev => [...prev, newTeacher]);
  };

  const updateTeacherAvatar = (id: string, avatarUrl: string) => {
    setTeachers(prev => prev.map(t => t.id === id ? { ...t, avatarUrl } : t));
  };
  
  const deleteTeacher = (id: string) => {
    if (id === 'admin-001') return alert('No se puede eliminar la cuenta de Control de Guardias.');
    if (confirm('¿Eliminar a este profesor y todos sus datos vinculados?')) {
      setTeachers(prev => prev.filter(t => t.id !== id));
      setSchedules(prev => prev.filter(s => s.teacherId !== id));
      setAbsences(prev => prev.filter(a => a.teacherId !== id && a.substitutingTeacherId !== id));
    }
  };

  const updateTeacherSchedule = (teacherId: string, dayIndex: number, slotIndex: number, type: SlotType, course?: string) => {
    setSchedules(prev => {
      const filtered = prev.filter(s => !(s.teacherId === teacherId && s.dayIndex === dayOfWeek && s.slotIndex === slotIndex));
      return [...filtered, { teacherId, dayIndex, slotIndex, type, course }];
    });
  };

  const addAbsence = (teacherId: string, date: string, slotIndex: number, notes: string, manualCourse?: string) => {
    const dateObj = new Date(date);
    const dayOfWeek = (dateObj.getDay() + 6) % 7; 
    let finalCourse = manualCourse;
    if (!finalCourse) {
      const match = schedules.find(s => s.teacherId === teacherId && s.dayIndex === dayOfWeek && s.slotIndex === slotIndex);
      finalCourse = match?.course || '';
    }
    setAbsences(prev => [...prev, { 
      id: Math.random().toString(36).substr(2, 9), 
      teacherId, date, slotIndex, notes, course: finalCourse, type: TIME_SLOTS[slotIndex].isRecess ? 'PATIO' : 'CLASE' 
    }]);
  };

  const assignSubstitution = (absenceId: string, subId: string) => setAbsences(prev => prev.map(a => a.id === absenceId ? { ...a, substitutingTeacherId: subId } : a));
  const deleteAbsence = (id: string) => setAbsences(prev => prev.filter(a => a.id !== id));
  const updateAbsenceNotes = (id: string, notes: string) => setAbsences(prev => prev.map(a => a.id === id ? { ...a, notes } : a));

  const TeacherAvatar = ({ teacher, size = "md" }: { teacher?: Teacher, size?: "sm" | "md" | "lg" }) => {
    const sizeClasses = size === "sm" ? "w-8 h-8" : size === "lg" ? "w-24 h-24" : "w-12 h-12";
    
    if (teacher?.avatarUrl) {
      return (
        <div className={`${sizeClasses} rounded-2xl overflow-hidden border-2 border-indigo-100 shadow-sm`}>
          <img src={teacher.avatarUrl} alt={teacher.name} className="w-full h-full object-cover" />
        </div>
      );
    }

    const iconSize = size === "sm" ? 14 : size === "lg" ? 40 : 22;
    return (
      <div className={`${sizeClasses} bg-indigo-50 text-indigo-400 rounded-2xl flex items-center justify-center font-black border-2 border-indigo-100 uppercase`}>
        {teacher ? teacher.name.charAt(0) : <UserIcon size={iconSize} />}
      </div>
    );
  };

  const SidebarItem = ({ icon: Icon, label, target, active }: any) => (
    <button onClick={() => { setView(target); setSelectedTeacherForSchedule(null); }} className={`w-full flex items-center gap-4 px-6 py-4 rounded-2xl text-sm font-bold transition-all ${active ? 'bg-indigo-600 text-white shadow-xl' : 'text-slate-500 hover:bg-slate-100'}`}>
      <Icon size={20} /> {label}
    </button>
  );

  return (
    <div className="flex flex-col lg:flex-row min-h-screen bg-slate-50 font-inter">
      {/* Sidebar */}
      <aside className="w-full lg:w-80 bg-white border-b lg:border-r border-slate-200 lg:h-screen flex flex-col sticky top-0 z-50">
        <div className="p-10 flex items-center gap-4">
          <div className="w-12 h-12 bg-indigo-600 rounded-[18px] flex items-center justify-center text-white shadow-lg"><ClipboardCheck size={24} /></div>
          <span className="font-black text-2xl tracking-tighter">CEMM_GUARDIAS</span>
        </div>
        <nav className="flex-1 px-6 space-y-2 overflow-y-auto">
          <SidebarItem icon={Calendar} label="Panel Principal" target="dashboard" active={view === 'dashboard'} />
          <SidebarItem icon={BookOpen} label="Tabla_Guardias" target="daily-tasks" active={view === 'daily-tasks'} />
          <SidebarItem icon={CalendarRange} label="Guardia_General" target="master-guards" active={view === 'master-guards'} />
          
          <div className="pt-8 space-y-2">
            <div className="px-6 mb-4 text-[10px] font-black text-slate-300 uppercase tracking-widest">Gestión Central</div>
            <SidebarItem icon={ShieldAlert} label="Gestión de Faltas" target="absences" active={view === 'absences'} />
            <SidebarItem icon={Clock} label="Horarios Docentes" target="manage-schedules" active={view === 'manage-schedules'} />
            <SidebarItem icon={Users} label="Plantilla Docente" target="teachers" active={view === 'teachers'} />
            <SidebarItem icon={BarChart3} label="Estadísticas" target="stats" active={view === 'stats'} />
          </div>
        </nav>
        <div className="p-8 border-t border-slate-100">
          <div className="p-5 rounded-[30px] bg-slate-50 flex items-center gap-4">
            <TeacherAvatar teacher={teachers.find(t => t.id === 'admin-001')} size="sm" />
            <div>
              <p className="text-xs font-black truncate">Control de Guardias</p>
              <span className="text-[9px] font-black text-indigo-600 uppercase">Administrador</span>
            </div>
          </div>
        </div>
      </aside>

      {/* Main Content */}
      <main className="flex-1 p-8 lg:p-14 overflow-x-hidden">
        <div className="max-w-6xl mx-auto">
          {view === 'dashboard' && <DashboardView teachers={teachers} absences={absences} />}
          {view === 'teachers' && <TeachersView teachers={teachers} onAdd={addTeacher} onDelete={deleteTeacher} onUpdateAvatar={updateTeacherAvatar} TeacherAvatar={TeacherAvatar} />}
          {view === 'manage-schedules' && !selectedTeacherForSchedule && (
             <SchedulesListView teachers={teachers} onSelect={setSelectedTeacherForSchedule} TeacherAvatar={TeacherAvatar} />
          )}
          {view === 'manage-schedules' && selectedTeacherForSchedule && (
             <ScheduleEditorView teacher={selectedTeacherForSchedule} schedules={schedules} updateSlot={updateTeacherSchedule} onBack={() => setSelectedTeacherForSchedule(null)} />
          )}
          {view === 'absences' && <AbsencesView teachers={teachers} absences={absences} schedules={schedules} addAbsence={addAbsence} deleteAbsence={deleteAbsence} assignSubstitution={assignSubstitution} TeacherAvatar={TeacherAvatar} />}
          {view === 'daily-tasks' && <DailyTasksView teachers={teachers} absences={absences} updateNotes={updateAbsenceNotes} TeacherAvatar={TeacherAvatar} />}
          {/* Fix: Passed TeacherAvatar to MasterGuardsView */}
          {view === 'master-guards' && <MasterGuardsView teachers={teachers} schedules={schedules} absences={absences} TeacherAvatar={TeacherAvatar} />}
          {/* Fix: Passed TeacherAvatar to StatsView */}
          {view === 'stats' && <StatsView teachers={teachers} absences={absences} TeacherAvatar={TeacherAvatar} />}
        </div>
      </main>
    </div>
  );
};

// --- SUB-COMPONENTES ---

const DashboardView = ({ teachers, absences }: any) => {
  const today = new Date().toISOString().split('T')[0];
  const todayAbsences = absences.filter((a: any) => a.date === today);
  const covered = todayAbsences.filter((a: any) => a.substitutingTeacherId).length;
  
  return (
    <div className="space-y-12 animate-in fade-in duration-700">
      <header className="flex flex-col gap-4">
        <div className="flex items-center gap-2 text-indigo-600 font-black text-[10px] uppercase tracking-widest"><Sparkles size={14} /> Sistema CEMM_GUARDIAS</div>
        <h2 className="text-5xl font-black text-slate-900 tracking-tight">Estado del Centro</h2>
      </header>
      <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
        <div className="bg-white p-10 rounded-[45px] border border-slate-100 shadow-sm">
          <p className="text-slate-400 text-[10px] font-black uppercase mb-4">Faltas Hoy</p>
          <p className="text-6xl font-black text-red-500">{todayAbsences.length}</p>
        </div>
        <div className="bg-white p-10 rounded-[45px] border border-slate-100 shadow-sm">
          <p className="text-slate-400 text-[10px] font-black uppercase mb-4">Cubiertas</p>
          <p className="text-6xl font-black text-emerald-500">{covered}</p>
        </div>
        <div className="bg-white p-10 rounded-[45px] border border-slate-100 shadow-sm">
          <p className="text-slate-400 text-[10px] font-black uppercase mb-4">Pendientes</p>
          <p className="text-6xl font-black text-amber-500">{todayAbsences.length - covered}</p>
        </div>
        <div className="bg-white p-10 rounded-[45px] border border-slate-100 shadow-sm">
          <p className="text-slate-400 text-[10px] font-black uppercase mb-4">Profesores</p>
          <p className="text-6xl font-black text-slate-800">{teachers.length}</p>
        </div>
      </div>
    </div>
  );
};

const TeachersView = ({ teachers, onAdd, onDelete, onUpdateAvatar, TeacherAvatar }: any) => {
  const [showAdd, setShowAdd] = useState(false);
  const [name, setName] = useState('');
  const [tempAvatar, setTempAvatar] = useState<string | undefined>(undefined);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>, teacherId?: string) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        const base64 = reader.result as string;
        if (teacherId) {
          onUpdateAvatar(teacherId, base64);
        } else {
          setTempAvatar(base64);
        }
      };
      reader.readAsDataURL(file);
    }
  };

  return (
    <div className="space-y-12 animate-in slide-in-from-bottom-6">
      <header className="flex items-center justify-between">
        <h2 className="text-5xl font-black text-slate-900 tracking-tight">Plantilla Docente</h2>
        <button onClick={() => { setShowAdd(!showAdd); setTempAvatar(undefined); }} className="bg-indigo-600 text-white font-black px-10 py-5 rounded-[30px] flex items-center gap-3 hover:scale-105 transition-all shadow-xl shadow-indigo-100">
          <UserPlus size={22} /> Añadir Docente
        </button>
      </header>
      
      {showAdd && (
        <form onSubmit={e => { e.preventDefault(); onAdd(name, tempAvatar); setName(''); setTempAvatar(undefined); setShowAdd(false); }} className="bg-white p-12 rounded-[50px] shadow-2xl border-4 border-indigo-50 flex flex-col md:flex-row gap-8 items-center animate-in zoom-in-95">
          <div className="relative group">
            <div className="w-32 h-32 bg-slate-50 rounded-[40px] border-4 border-dashed border-slate-200 flex items-center justify-center overflow-hidden">
              {tempAvatar ? (
                <img src={tempAvatar} className="w-full h-full object-cover" />
              ) : (
                <Camera className="text-slate-300" size={32} />
              )}
            </div>
            <button type="button" onClick={() => fileInputRef.current?.click()} className="absolute -bottom-2 -right-2 bg-indigo-600 text-white p-3 rounded-2xl shadow-lg hover:scale-110 transition-all">
              <Upload size={16} />
            </button>
            <input type="file" ref={fileInputRef} className="hidden" accept="image/*" onChange={(e) => handleFileChange(e)} />
          </div>
          
          <div className="flex-1 flex flex-col gap-2 w-full">
            <label className="text-[10px] font-black uppercase text-slate-400 ml-4">Nombre Completo</label>
            <input required value={name} onChange={e => setName(e.target.value)} placeholder="Ej: Juan Pérez García" className="px-8 py-5 rounded-[30px] bg-slate-50 font-bold text-lg border-2 border-transparent focus:border-indigo-500 outline-none w-full" />
          </div>
          <button type="submit" className="bg-indigo-600 text-white font-black px-12 py-5 rounded-[30px] uppercase text-xs w-full md:w-auto h-fit">Guardar Registro</button>
        </form>
      )}

      <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
        {teachers.map((t: Teacher) => (
          <div key={t.id} className="bg-white p-10 rounded-[45px] border border-slate-100 shadow-sm text-center group relative overflow-hidden transition-all hover:shadow-xl">
            <div className={`absolute top-6 right-8 text-[8px] font-black uppercase px-3 py-1 rounded-full ${t.role === 'admin' ? 'bg-indigo-600 text-white' : 'bg-slate-50 text-slate-400'}`}>
              {t.role === 'admin' ? 'Control de Guardias' : 'Docente'}
            </div>
            
            <div className="relative mb-6 mx-auto inline-block">
              <TeacherAvatar teacher={t} size="lg" />
              <button 
                onClick={() => {
                  const input = document.createElement('input');
                  input.type = 'file';
                  input.accept = 'image/*';
                  input.onchange = (e: any) => handleFileChange(e, t.id);
                  input.click();
                }}
                className="absolute -bottom-1 -right-1 bg-white p-2 rounded-xl shadow-md text-indigo-600 border border-slate-100 opacity-0 group-hover:opacity-100 transition-opacity"
              >
                <Camera size={14} />
              </button>
            </div>
            
            <h4 className="font-black text-slate-800 text-xl mb-4 truncate">{t.name}</h4>
            
            {t.id !== 'admin-001' && (
              <button onClick={() => onDelete(t.id)} className="text-slate-200 hover:text-red-500 transition-colors mt-2">
                <Trash2 size={20} />
              </button>
            )}
          </div>
        ))}
      </div>
    </div>
  );
};

const SchedulesListView = ({ teachers, onSelect, TeacherAvatar }: any) => (
  <div className="space-y-12 animate-in fade-in duration-500">
    <header><h2 className="text-5xl font-black text-slate-900 tracking-tight">Gestión de Horarios</h2></header>
    <div className="bg-white rounded-[50px] shadow-sm border border-slate-100 overflow-hidden">
      <div className="p-8 border-b border-slate-50 bg-slate-50/50"><p className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Seleccione un perfil para editar su horario semanal</p></div>
      <div className="grid grid-cols-1 divide-y divide-slate-50">
        {teachers.map((t: Teacher) => (
          <button key={t.id} onClick={() => onSelect(t)} className="flex items-center justify-between p-8 hover:bg-indigo-50/50 group transition-all text-left">
            <div className="flex items-center gap-6">
              <TeacherAvatar teacher={t} size="md" />
              <div>
                <p className="font-black text-slate-800 text-lg">{t.name}</p>
                <p className="text-[10px] font-black text-slate-400 uppercase">{t.role === 'admin' ? 'Control de Guardias' : 'Personal Docente'}</p>
              </div>
            </div>
            <div className="bg-slate-50 p-4 rounded-2xl group-hover:bg-indigo-600 group-hover:text-white transition-all"><ChevronRight size={20} /></div>
          </button>
        ))}
      </div>
    </div>
  </div>
);

const ScheduleEditorView = ({ teacher, schedules, updateSlot, onBack }: any) => {
  const list = schedules.filter((s: any) => s.teacherId === teacher.id);
  const get = (day: number, slot: number) => list.find((s: any) => s.dayIndex === day && s.slotIndex === slot);
  
  return (
    <div className="space-y-10 animate-in slide-in-from-right-10 duration-500">
      <header className="flex items-center gap-6">
        <button onClick={onBack} className="p-5 bg-white rounded-[25px] border border-slate-100 shadow-sm hover:bg-slate-50 transition-all"><ChevronLeft size={24} /></button>
        <div>
          <h2 className="text-4xl font-black text-slate-900 tracking-tight">Horario de {teacher.name}</h2>
          <p className="text-[10px] font-black text-indigo-600 uppercase mt-1">Configuración del Control de Guardias</p>
        </div>
      </header>
      <div className="bg-white rounded-[50px] shadow-sm border border-slate-100 overflow-x-auto custom-scrollbar">
        <table className="w-full text-center border-collapse">
          <thead>
            <tr>
              <th className="p-8 bg-slate-50 border-b border-slate-100 text-[11px] font-black text-slate-400 uppercase w-32">Tramo</th>
              {DAYS_OF_WEEK.map((day, idx) => (<th key={idx} className="p-8 bg-slate-50 border-b border-slate-100 text-sm font-black text-slate-800 uppercase">{day}</th>))}
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-50">
            {TIME_SLOTS.map((slot, sIdx) => (
              <tr key={sIdx}>
                <td className="p-6 bg-slate-50/30 font-black text-xs text-slate-800">
                  <div className="flex flex-col">
                    <span>{slot.label}</span>
                    <span className="text-[9px] text-slate-400 font-normal">{slot.start} - {slot.end}</span>
                  </div>
                </td>
                {DAYS_OF_WEEK.map((_, dIdx) => {
                  const s = get(dIdx, sIdx);
                  const type = s?.type || 'LIBRE';
                  const course = s?.course || '';
                  return (
                    <td key={dIdx} className="p-4 min-w-[150px]">
                      <div className="flex flex-col gap-2">
                        <select 
                          value={type} 
                          onChange={e => updateSlot(teacher.id, dIdx, sIdx, e.target.value as SlotType, type === 'CLASE' ? course : '')} 
                          className={`w-full p-3 text-[10px] rounded-2xl font-black uppercase appearance-none outline-none text-center transition-all ${type === 'CLASE' ? 'bg-indigo-600 text-white shadow-lg' : type.includes('GUARDIA') ? 'bg-amber-100 text-amber-700 border border-amber-200' : 'bg-slate-50 text-slate-300'}`}
                        >
                          <option value="LIBRE">Libre</option>
                          <option value="CLASE">Clase</option>
                          <option value="GUARDIA_SUSTITUCION">Guardia</option>
                          {slot.isRecess && <option value="GUARDIA_PATIO">Patio</option>}
                          <option value="RDP">RDP</option>
                          <option value="COMEDOR">Comedor</option>
                        </select>
                        {type === 'CLASE' && (
                          <input 
                            type="text" 
                            placeholder="Grupo..." 
                            value={course} 
                            onChange={e => updateSlot(teacher.id, dIdx, sIdx, type, e.target.value)} 
                            className="w-full p-2.5 bg-white border-2 border-indigo-100 rounded-xl text-[10px] font-black text-indigo-700 text-center outline-none" 
                          />
                        )}
                      </div>
                    </td>
                  );
                })}
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
};

const AbsencesView = ({ teachers, absences, schedules, addAbsence, deleteAbsence, assignSubstitution, TeacherAvatar }: any) => {
  const [showAdd, setShowAdd] = useState(false);
  const [form, setForm] = useState({ teacherId: '', date: new Date().toISOString().split('T')[0], slotIndex: 0, manualCourse: '' });

  useEffect(() => {
    if (form.teacherId && form.date) {
      const d = new Date(form.date);
      const dayOfWeek = (d.getDay() + 6) % 7; 
      const match = schedules.find((s:any) => s.teacherId === form.teacherId && s.dayIndex === dayOfWeek && s.slotIndex === form.slotIndex);
      setForm(prev => ({ ...prev, manualCourse: (match?.type === 'CLASE' ? match.course : '') || '' }));
    }
  }, [form.teacherId, form.date, form.slotIndex, schedules]);

  return (
    <div className="space-y-12 animate-in slide-in-from-top-6 duration-700">
      <header className="flex items-center justify-between">
        <h2 className="text-5xl font-black text-slate-900 tracking-tight">Gestión de Faltas</h2>
        <button onClick={() => setShowAdd(!showAdd)} className="bg-red-500 text-white font-black px-10 py-5 rounded-[30px] shadow-2xl shadow-red-100 flex items-center gap-3 hover:scale-105 transition-all">
          <ShieldAlert size={22} /> Registrar Falta
        </button>
      </header>
      {showAdd && (
        <div className="bg-white p-12 rounded-[50px] shadow-2xl border-4 border-red-50 animate-in zoom-in-95">
          <form className="grid grid-cols-1 md:grid-cols-4 gap-8" onSubmit={e => { e.preventDefault(); addAbsence(form.teacherId, form.date, form.slotIndex, '', form.manualCourse); setShowAdd(false); }}>
            <div className="flex flex-col gap-2 text-left">
              <label className="text-[10px] font-black uppercase text-slate-400 ml-4">Profesor Ausente</label>
              <select required value={form.teacherId} onChange={e => setForm({...form, teacherId: e.target.value})} className="p-5 rounded-[25px] bg-slate-50 font-bold text-sm">
                <option value="">Seleccionar...</option>
                {teachers.map((t: any) => <option key={t.id} value={t.id}>{t.name}</option>)}
              </select>
            </div>
            <div className="flex flex-col gap-2 text-left">
              <label className="text-[10px] font-black uppercase text-slate-400 ml-4">Fecha</label>
              <input required type="date" value={form.date} onChange={e => setForm({...form, date: e.target.value})} className="p-5 rounded-[25px] bg-slate-50 font-bold text-sm" />
            </div>
            <div className="flex flex-col gap-2 text-left">
              <label className="text-[10px] font-black uppercase text-slate-400 ml-4">Tramo Horario</label>
              <select value={form.slotIndex} onChange={e => setForm({...form, slotIndex: parseInt(e.target.value)})} className="p-5 rounded-[25px] bg-slate-50 font-bold text-sm">
                {TIME_SLOTS.map((s, idx) => <option key={idx} value={idx}>{s.label}</option>)}
              </select>
            </div>
            <div className="flex flex-col gap-2 text-left">
              <label className="text-[10px] font-black uppercase text-slate-400 ml-4 flex items-center gap-2">Grupo/Aula {form.manualCourse && <Zap size={10} className="text-amber-500 fill-amber-500" />}</label>
              <input required value={form.manualCourse} onChange={e => setForm({...form, manualCourse: e.target.value})} className={`p-5 rounded-[25px] font-bold text-sm outline-none transition-all ${form.manualCourse ? 'bg-amber-50' : 'bg-slate-50'}`} />
            </div>
            <div className="md:col-span-4 flex justify-end">
              <button type="submit" className="px-12 py-5 bg-slate-900 text-white font-black rounded-[25px] shadow-xl hover:bg-indigo-600 transition-all">Guardar Ausencia</button>
            </div>
          </form>
        </div>
      )}
      <div className="bg-white rounded-[50px] shadow-sm border border-slate-100 overflow-hidden">
        <table className="w-full text-left">
          <thead className="bg-slate-50 text-slate-400 text-[10px] font-black uppercase tracking-widest">
            <tr>
              <th className="px-10 py-8">Fecha y Tramo</th>
              <th className="px-10 py-8 text-center">Docente</th>
              <th className="px-10 py-8 text-center">Grupo</th>
              <th className="px-10 py-8">Sustituto Asignado</th>
              <th className="px-10 py-8 text-right">Acciones</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-50">
            {[...absences].reverse().map(a => {
              const prof = teachers.find((t:any) => t.id === a.teacherId);
              const dateObj = new Date(a.date);
              const dayOfWeek = (dateObj.getDay() + 6) % 7; 
              
              const onGuard = teachers.filter(t => t.id !== a.teacherId && schedules.some(s => s.teacherId === t.id && s.dayIndex === dayOfWeek && s.slotIndex === a.slotIndex && (s.type === 'GUARDIA_SUSTITUCION' || s.type === 'GUARDIA_PATIO')));
              const others = teachers.filter(t => t.id !== a.teacherId && !onGuard.some(og => og.id === t.id));

              return (
                <tr key={a.id} className="hover:bg-slate-50/50 group transition-all">
                  <td className="px-10 py-8">
                    <p className="font-black text-slate-800 text-base">{dateObj.toLocaleDateString()}</p>
                    <p className="text-[10px] text-indigo-500 font-black uppercase">{TIME_SLOTS[a.slotIndex].label}</p>
                  </td>
                  <td className="px-10 py-8 text-center">
                    <div className="flex items-center justify-center gap-4">
                      <TeacherAvatar teacher={prof} size="sm" />
                      <span className="font-black text-sm">{prof?.name}</span>
                    </div>
                  </td>
                  <td className="px-10 py-8 text-center">
                    <span className="text-[11px] font-black text-slate-500 bg-slate-100 px-4 py-2 rounded-xl uppercase">{a.course || 'N/A'}</span>
                  </td>
                  <td className="px-10 py-8">
                    <select value={a.substitutingTeacherId || ''} onChange={e => assignSubstitution(a.id, e.target.value)} className="w-full p-4 rounded-[20px] bg-slate-50 text-[10px] font-black uppercase outline-none focus:ring-4 focus:ring-indigo-50 transition-all">
                      <option value="">-- Sin sustituto --</option>
                      <optgroup label="EN GUARDIA (PREFERENTE)">
                        {onGuard.map(t => <option key={t.id} value={t.id}>{t.name}</option>)}
                      </optgroup>
                      <optgroup label="OTROS DOCENTES">
                        {others.map(t => <option key={t.id} value={t.id}>{t.name}</option>)}
                      </optgroup>
                    </select>
                  </td>
                  <td className="px-10 py-8 text-right">
                    <button onClick={() => deleteAbsence(a.id)} className="p-4 text-slate-200 hover:text-red-500 transition-all opacity-0 group-hover:opacity-100">
                      <Trash2 size={20} />
                    </button>
                  </td>
                </tr>
              )
            })}
            {absences.length === 0 && (
               <tr><td colSpan={5} className="py-24 text-center text-slate-300 font-black uppercase text-xs tracking-widest">Sin registros</td></tr>
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
};

/* Fix: Added TeacherAvatar to MasterGuardsView props */
const MasterGuardsView = ({ teachers, schedules, absences, TeacherAvatar }: any) => {
  const today = new Date().toISOString().split('T')[0];
  const todayAbsences = absences.filter((a: any) => a.date === today);

  return (
    <div className="space-y-12 animate-in slide-in-from-left-6 duration-700">
      <header className="flex items-center justify-between">
        <h2 className="text-5xl font-black text-slate-900 tracking-tight">Guardia_General</h2>
        <div className="flex items-center gap-2 bg-indigo-50 px-6 py-3 rounded-2xl">
          <div className="w-2 h-2 bg-indigo-600 rounded-full animate-pulse"></div>
          <span className="text-[10px] font-black text-indigo-600 uppercase">CEMM_SINCRO</span>
        </div>
      </header>
      <div className="bg-white rounded-[50px] shadow-sm border border-slate-100 overflow-x-auto custom-scrollbar">
        <table className="w-full text-center border-collapse">
          <thead>
            <tr>
              <th className="p-8 bg-slate-50 border-b border-r border-slate-100 text-[11px] font-black text-slate-400 uppercase w-32 tracking-widest">Horario</th>
              {DAYS_OF_WEEK.map((day, dIdx) => (<th key={dIdx} className="p-8 bg-slate-50 border-b border-slate-100 text-[11px] font-black text-slate-800 uppercase min-w-[200px]">{day}</th>))}
            </tr>
          </thead>
          <tbody>
            {TIME_SLOTS.map((slot, sIdx) => (
              <tr key={sIdx}>
                <td className="p-8 border-b border-r border-slate-50 bg-slate-50/30 font-black text-[11px] text-slate-800 uppercase">{slot.label}</td>
                {DAYS_OF_WEEK.map((_, dIdx) => {
                  const guards = teachers.filter(t => schedules.some(s => s.teacherId === t.id && s.dayIndex === dIdx && s.slotIndex === sIdx && (s.type === 'GUARDIA_SUSTITUCION' || s.type === 'GUARDIA_PATIO')));
                  return (
                    <td key={dIdx} className="p-4 border-b border-slate-50 align-top">
                      <div className="flex flex-col gap-2 min-h-[100px]">
                        {guards.length > 0 ? guards.map(t => {
                          const currentAbsence = todayAbsences.find((a:any) => a.substitutingTeacherId === t.id && a.slotIndex === sIdx);
                          const isOccupied = !!currentAbsence;
                          return (
                            <div key={t.id} className={`p-4 rounded-[25px] border transition-all text-left group flex items-center gap-3 ${isOccupied ? 'bg-amber-50 border-amber-200' : 'bg-indigo-50 border-indigo-100'}`}>
                              <TeacherAvatar teacher={t} size="sm" />
                              <div className="flex-1 overflow-hidden">
                                <span className={`text-[10px] font-black block truncate ${isOccupied ? 'text-amber-700' : 'text-indigo-700'}`}>{t.name}</span>
                                {isOccupied ? (
                                  <span className="text-[8px] font-black uppercase text-amber-500">OCUPADO ({currentAbsence.course})</span>
                                ) : (
                                  <span className="text-[8px] font-black uppercase text-indigo-400">DISPONIBLE</span>
                                )}
                              </div>
                            </div>
                          );
                        }) : <span className="opacity-10 font-black text-[10px] uppercase mt-8 block tracking-widest">—</span>}
                      </div>
                    </td>
                  );
                })}
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
};

const DailyTasksView = ({ teachers, absences, updateNotes, TeacherAvatar }: any) => {
  const [selectedDate, setSelectedDate] = useState(new Date().toISOString().split('T')[0]);
  const dailyAbsences = absences.filter((a: any) => a.date === selectedDate);
  
  return (
    <div className="space-y-12 animate-in fade-in duration-700">
      <header className="flex items-center justify-between">
        <h2 className="text-5xl font-black text-slate-900 tracking-tight">Tabla_Guardias</h2>
        <div className="flex items-center gap-4 bg-white px-6 py-3 rounded-3xl shadow-sm border border-slate-100">
          <CalendarCheck size={20} className="text-indigo-500" />
          <input type="date" value={selectedDate} onChange={e => setSelectedDate(e.target.value)} className="font-black text-sm outline-none" />
        </div>
      </header>
      <div className="bg-white rounded-[50px] shadow-sm border border-slate-100 overflow-hidden">
        <table className="w-full text-left">
          <thead className="bg-slate-50 text-slate-400 text-[10px] font-black uppercase tracking-widest">
            <tr>
              <th className="px-10 py-8">Profesor Ausente</th>
              <th className="px-10 py-8 text-center">Hora</th>
              <th className="px-10 py-8 text-center">Grupo</th>
              <th className="px-10 py-8 w-1/3">Instrucciones CEMM</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-50">
            {dailyAbsences.length > 0 ? dailyAbsences.map((a: any) => (
              <tr key={a.id}>
                <td className="px-10 py-8">
                  <div className="flex items-center gap-5">
                    <TeacherAvatar teacher={teachers.find((t:any) => t.id === a.teacherId)} size="sm" />
                    <span className="font-black text-slate-800 text-sm">{teachers.find((t: any) => t.id === a.teacherId)?.name}</span>
                  </div>
                </td>
                <td className="px-10 py-8 text-center font-black text-[11px] text-indigo-500 uppercase">{TIME_SLOTS[a.slotIndex].label}</td>
                <td className="px-10 py-8 text-center font-black text-[11px] text-slate-400 uppercase">{a.course || 'N/A'}</td>
                <td className="px-10 py-8">
                  <textarea 
                    value={a.notes || ''} 
                    onChange={e => updateNotes(a.id, e.target.value)} 
                    placeholder="Detallar tareas para la guardia..." 
                    className="w-full min-h-[100px] p-6 text-sm bg-slate-50 border-2 border-slate-100 rounded-[30px] outline-none focus:border-indigo-500 transition-all resize-none shadow-inner" 
                  />
                </td>
              </tr>
            )) : (
              <tr><td colSpan={4} className="py-32 text-center text-slate-300 font-black uppercase text-xs tracking-widest italic">No hay ausencias</td></tr>
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
};

/* Fix: Added TeacherAvatar to StatsView props */
const StatsView = ({ teachers, absences, TeacherAvatar }: any) => (
  <div className="space-y-12 animate-in slide-in-from-right-6 duration-700">
    <h2 className="text-5xl font-black text-slate-900 tracking-tight">Estadísticas CEMM</h2>
    <div className="bg-white rounded-[50px] shadow-sm border border-slate-100 overflow-hidden">
      <table className="w-full text-left">
        <thead className="bg-slate-50 text-slate-400 text-[10px] font-black uppercase">
          <tr>
            <th className="px-12 py-10">Docente</th>
            <th className="px-12 py-10 text-center">Sustituciones</th>
            <th className="px-12 py-10 text-center">Patios</th>
            <th className="px-12 py-10 text-right">Acumulado</th>
          </tr>
        </thead>
        <tbody className="divide-y divide-slate-50">
          {teachers.map((t: Teacher) => {
            const stats = {
              subs: absences.filter((a:any) => a.substitutingTeacherId === t.id && a.type === 'CLASE').length,
              patio: absences.filter((a:any) => a.substitutingTeacherId === t.id && a.type === 'PATIO').length,
            };
            return (
              <tr key={t.id} className="hover:bg-slate-50/30 transition-all">
                <td className="px-12 py-10 flex items-center gap-4">
                  <TeacherAvatar teacher={t} size="sm" />
                  <p className="font-black text-slate-800 text-lg">{t.name}</p>
                </td>
                <td className="px-12 py-10 text-center font-black text-3xl text-indigo-600">{stats.subs}</td>
                <td className="px-12 py-10 text-center font-black text-3xl text-purple-600">{stats.patio}</td>
                <td className="px-12 py-10 text-right">
                  <div className="inline-flex items-center gap-4 bg-slate-900 text-white px-8 py-4 rounded-[25px] shadow-lg">
                    <span className="text-[10px] font-black uppercase tracking-widest opacity-60">Total</span>
                    <span className="text-xl font-black">{stats.subs + stats.patio} h</span>
                  </div>
                </td>
              </tr>
            );
          })}
        </tbody>
      </table>
    </div>
  </div>
);

export default App;
