
export type Role = 'teacher' | 'admin';

export type SlotType = 'CLASE' | 'GUARDIA_SUSTITUCION' | 'GUARDIA_PATIO' | 'COMEDOR' | 'RDP' | 'LIBRE';

export interface Teacher {
  id: string;
  name: string;
  role: Role;
  avatarUrl?: string;
}

export interface ScheduleEntry {
  teacherId: string;
  dayIndex: number; 
  slotIndex: number; 
  type: SlotType;
  course?: string; 
}

export interface Absence {
  id: string;
  teacherId: string;
  date: string; 
  slotIndex: number;
  notes?: string;
  course?: string; 
  substitutingTeacherId?: string; 
  type: 'CLASE' | 'PATIO'; 
}

export interface TimeSlot {
  label: string;
  start: string;
  end: string;
  isRecess?: boolean;
}
