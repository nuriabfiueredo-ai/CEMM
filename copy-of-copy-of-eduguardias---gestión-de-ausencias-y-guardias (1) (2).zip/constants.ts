
import { TimeSlot } from './types';

export const TIME_SLOTS: TimeSlot[] = [
  { label: '1ª Hora', start: '08:00', end: '08:55' },
  { label: '2ª Hora', start: '08:55', end: '09:50' },
  { label: '3ª Hora', start: '09:50', end: '10:45' },
  { label: 'Patio', start: '10:45', end: '11:15', isRecess: true },
  { label: '4ª Hora', start: '11:15', end: '12:10' },
  { label: '5ª Hora', start: '12:10', end: '13:05' },
  { label: '6ª Hora', start: '13:05', end: '14:00' },
  { label: '7ª Hora', start: '14:00', end: '15:00' },
  { label: '8ª Hora', start: '15:00', end: '15:55' },
];

export const DAYS_OF_WEEK = ['Lunes', 'Martes', 'Miércoles', 'Jueves', 'Viernes'];

export const SLOT_TYPES_LABELS: Record<string, string> = {
  CLASE: 'Clase',
  GUARDIA_SUSTITUCION: 'Guardia Sustitución',
  GUARDIA_PATIO: 'Guardia Patio',
  COMEDOR: 'Comedor',
  RDP: 'Reunión Departamento',
  LIBRE: 'Libre'
};
